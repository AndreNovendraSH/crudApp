@extends('layout.app')

@section('content')
    <h1>Transaksi Penjualan</h1>
    <form action="{{ route('transactions.store') }}" method="POST">
        @csrf
        <label for="product_id">Produk</label>
        <select name="product_id" required>
            @foreach ($products as $product)
                <option value="{{ $product->id }}">{{ $product->name }} - {{ $product->price }}</option>
            @endforeach
        </select>

        <label for="quantity">Jumlah</label>
        <input type="number" name="quantity" required>

        <button type="submit">Proses Transaksi</button>
    </form>
@endsection
