<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Transaction;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function create()
    {
        $products = Product::all();
        return view('transactions.create', compact('product'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required',
            'quantity' => 'required|integer',
        ]);

        $product = Product::find($request->product_id);
        $total = $product->price * $request->quantity;

        Transaction::create([
            'product_id' => $product->id,
            'quantity' => $request->quantity,
            'total' => $total,
        ]);

        // Update stock
        $product->decrement('stock', $request->quantity);

        return redirect()->route('transactions.create')->with('success', 'Transaction completed');
    }
}

